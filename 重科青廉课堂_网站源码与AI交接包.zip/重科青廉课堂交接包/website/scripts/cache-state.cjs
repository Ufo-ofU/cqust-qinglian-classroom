const fs=require('fs');
const p='app/api/classroom/[action]/route.ts';
let s=fs.readFileSync(p,'utf8');
s=s.replace("const s=await getSession(code);if(!s)return json({error:'没有找到这间课堂，请核对课堂码'},404);\n if(action==='state')return json({session:await view(s)});",`// Short-lived shared cache limits repeated database reads from large classrooms.
 const cache = (globalThis.caches as unknown as {default?:Cache})?.default;
 const cacheKey = new Request(new URL('/api/classroom/state?code='+code,req.url));
 if(action==='state' && cache){const cached=await cache.match(cacheKey);if(cached){const headers=new Headers(cached.headers);headers.set('Cache-Control','no-store');return new Response(cached.body,{headers})}}
 const s=await getSession(code);if(!s)return json({error:'没有找到这间课堂，请核对课堂码'},404);
 if(action==='state'){const payload={session:await view(s)};if(cache)try{await cache.put(cacheKey,Response.json(payload,{headers:{'Cache-Control':'public, max-age=2'}}))}catch{}return json(payload)};`);
fs.writeFileSync(p,s);
